import React from 'react';
import ReactDom from 'react-dom';


function Root() {
  return (
    <div>
      <h2>从这里开始前后端分离项目之旅</h2>
    </div>
  );
}




ReactDom.render(<Root />, document.getElementById('root'));


