//import store from 'store';



s = new Date()


setTimeout(() => {
    e = new Date();
    console.log(s - e);
}, 3000);

